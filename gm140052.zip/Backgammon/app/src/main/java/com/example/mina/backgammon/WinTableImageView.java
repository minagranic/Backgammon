package com.example.mina.backgammon;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.util.AttributeSet;

import com.example.mina.backgammon.beans.Stub;
import com.example.mina.backgammon.beans.Zeton;

/**
 * Created by Mina on 15-Feb-18.
 */

public class WinTableImageView extends android.support.v7.widget.AppCompatImageView {
    Paint paint = new Paint(Color.BLACK);
    static Bitmap tabla, zeton_beli, zeton_crni, zeton_crveni, kocka1, kocka2, kocka3, kocka4, kocka5, kocka6;
    private static final double BORDER_V_COEF = 0.1290628;
    private static final double BORDER_H_COEF = 0.060216231;
    private static final double TOKEN_HALF_LENGHT_COEF = 0.028575;
    private static final double DIE_WIDTH = 0.15;
    private static final double DIE_MIDDLE_DIST = 0.15;
    private Model model;
    private TableWin context = (TableWin) getContext();
    private double zeton_R;
    double coef = 0.8;

    public void dohvatiSlike() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        options.inDither = false;
        options.inSampleSize = 1;
        options.inScaled = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        tabla = BitmapFactory.decodeResource(getResources(), R.drawable.backgammon_board, options);
        zeton_beli = BitmapFactory.decodeResource(getResources(), R.drawable.chip_white, options);
        zeton_crni = BitmapFactory.decodeResource(getResources(), R.drawable.chip_black, options);
        zeton_crveni = BitmapFactory.decodeResource(getResources(), R.drawable.chip_red, options);
    }

    public WinTableImageView(Context context) {
        super(context);
        dodatno();
    }

    public WinTableImageView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        dodatno();
    }

    public WinTableImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        dodatno();
    }

    private void dodatno() {
        model = ((TableWin) context).getModel();
        dohvatiSlike();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        zeton_R = (int) (2 * TOKEN_HALF_LENGHT_COEF * getWidth() * coef);
        try {
            Rect r_table = new Rect(0, 0, getWidth(), getHeight());
            canvas.drawBitmap(tabla, null, r_table, paint);
            crtajPostavku(canvas);
            int drawn = 0;
            for (int i = 0; i < model.getBar().size(); i++) {
                Zeton z = model.getBar().get(i);
                if (z.getBoja() == Zeton.Boja.CRNA) {
                    if ((model.getDrzim() == null) || (model.getDrzim() != z)) {
                        Rect rect = new Rect((int) (getWidth() / 2 - zeton_R / 2),
                                (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R - zeton_R / 2),
                                (int) (getWidth() / 2 + zeton_R / 2),
                                (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R + zeton_R / 2));
                        canvas.drawBitmap(zeton_crni, null, rect, paint);
                    }
                    drawn++;
                }
            }
            for (int i = 0; i < model.getBar().size(); i++) {
                Zeton z = model.getBar().get(i);
                if ((z.getBoja() == Zeton.Boja.BELA)) {
                    Rect rect = new Rect((int) (getWidth() / 2 - zeton_R / 2),
                            (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R - zeton_R / 2),
                            (int) (getWidth() / 2 + zeton_R / 2),
                            (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R + zeton_R / 2));
                    canvas.drawBitmap(zeton_beli, null, rect, paint);
                    drawn++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void crtajPostavku(Canvas canvas) {
        try {

            Rect rect;
            double upper_left_x = 0;
            double upper_left_y = 0;
            for (int i = 1; i <= 24; i++) {
                Stub stub = model.getStub(i);
                for (int j = 0; j < stub.size(); j++) {
                    Zeton zeton = stub.getZetoni().get(j);
                    double[] xy = zetonXY(i, j);
                    upper_left_x = xy[0];
                    upper_left_y = xy[1];
                    rect = new Rect((int) upper_left_x, (int) upper_left_y, (int) (upper_left_x + zeton_R), (int) (upper_left_y + zeton_R));
                    Bitmap b;
                    if (zeton.getVidljivost() == Zeton.Vidljivost.POSSIBLE) {
                        b = zeton_crveni;
                    } else if (zeton.getBoja() == Zeton.Boja.BELA) {
                        b = zeton_beli;
                    } else {
                        b = zeton_crni;
                    }
                    canvas.drawBitmap(b, null, rect, paint);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public double[] zetonXY(int i, int j) {
        double upper_left_x = 0, upper_left_y = 0;
        double width = getWidth();
        double height = getHeight();
        double stub_w = (zeton_R / coef);

        if (i <= 6) {
            upper_left_x = width - BORDER_V_COEF * width - i * stub_w;
            upper_left_y = height - BORDER_H_COEF * height - zeton_R - j * zeton_R;
        } else if (i <= 12) {
            upper_left_x = BORDER_V_COEF * width + (12 - i) * stub_w;
            upper_left_y = height - BORDER_H_COEF * height - zeton_R - j * zeton_R;
        } else if (i <= 18) {
            upper_left_x = BORDER_V_COEF * width + (i - 13) * stub_w;
            upper_left_y = BORDER_H_COEF * height + (j) * zeton_R;
        } else if (i <= 24) {
            upper_left_x = width - BORDER_V_COEF * width - stub_w - (24 - i) * stub_w;
            upper_left_y = BORDER_H_COEF * height + (j) * zeton_R;
        } else if (i == 25) {
            upper_left_x = width / 2;
            upper_left_y = height / 2;
        }

        double[] xy = new double[2];
        xy[0] = upper_left_x;
        xy[1] = upper_left_y;
        return xy;

    }

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public void setContext(TableWin context) {
        this.context = context;
    }
}
