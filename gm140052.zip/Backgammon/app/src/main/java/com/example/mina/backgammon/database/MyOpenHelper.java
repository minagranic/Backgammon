package com.example.mina.backgammon.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mina.backgammon.Scores;

/**
 * Created by Mina on 15-Jan-18.
 */

public class MyOpenHelper extends SQLiteOpenHelper {
    // Svi parovi igraca koji su igrali igru
    private static final String CREATE_TABLE_SCORES = "CREATE TABLE " + ScoresEntry.TABLE_NAME + "(" +
            ScoresEntry._ID + " INTEGER PRIMARY KEY," +
            ScoresEntry.COLUMN_PLAYER1 + " TEXT, " +
            ScoresEntry.COLUMN_PLAYER2 + " TEXT);";
    // Postavka zetona
    private static final String CREATE_TABLE_SAVED = "CREATE TABLE " + TableEntry.TABLE_NAME + "(" +
            TableEntry._ID + " INTEGER PRIMARY KEY," +
            TableEntry.COLUMN_FIELD + " INTEGER, " +
            TableEntry.COLUMN_COLOR + " INTEGER, " +
            TableEntry.COLUMN_COUNT + " INTEGER" + ");";
    // Postavka zavrsene partije
    private static final String CREATE_TABLE_WIN = "CREATE TABLE " + TableEntry.TABLE_NAME_WIN + "(" +
            TableEntry._ID + " INTEGER PRIMARY KEY," +
            TableEntry.COLUMN_FIELD + " INTEGER, " +
            TableEntry.COLUMN_COLOR + " INTEGER, " +
            TableEntry.COLUMN_COUNT + " INTEGER, " +
            TableEntry.COLUMN_GAME_ID + " INTEGER, " +
            TableEntry.COLUMN_PAIR_ID + " INTEGER);";
    // Sacuvane kockice
    private static final String CREATE_TABLE_DICE = "CREATE TABLE " + DiceEntry.TABLE_NAME + "(" +
            DiceEntry._ID + " INTEGER PRIMARY KEY," +
            DiceEntry.COLUMN_NUMBER + " INTEGER);";
    // Sacuvani igraci za LOAD
    private static final String CREATE_TABLE_PLAYERS = "CREATE TABLE " + PlayerEntry.TABLE_NAME + "(" +
            PlayerEntry._ID + " INTEGER PRIMARY KEY," +
            PlayerEntry.COLUMN_PLAYER + " TEXT, " +
            PlayerEntry.COLUMN_COLOR + " INTEGER, " +
            PlayerEntry.COLUMN_MY_TURN + " INTEGER);";
    // Rezultat zavrsene partije
    private static final String CREATE_TABLE_GAMES = "CREATE TABLE " + GamesEntry.TABLE_NAME + "(" +
            GamesEntry._ID + " INTEGER PRIMARY KEY," +
            GamesEntry.COLUMN_PAIR_ID + " INTEGER, " +
            GamesEntry.COLUMN_POENI + " INTEGER);";


    private static final String DROP_TABLE_SCORES = "DROP TABLE IF EXISTS " + ScoresEntry.TABLE_NAME;
    private static final String DROP_TABLE_SAVED = "DROP TABLE IF EXISTS " + TableEntry.TABLE_NAME;
    private static final String DROP_TABLE_WIN = "DROP TABLE IF EXISTS " + TableEntry.TABLE_NAME_WIN;
    private static final String DROP_TABLE_DICE = "DROP TABLE IF EXISTS " + DiceEntry.TABLE_NAME;
    private static final String DROP_TABLE_PLAYERS = "DROP TABLE IF EXISTS " + PlayerEntry.TABLE_NAME;
    private static final String DROP_TABLE_GAMES = "DROP TABLE IF EXISTS " + GamesEntry.TABLE_NAME;

    public static final int DATABASE_VERSION = 8;
    public static final String DATABASE_NAME = "Backgammon.db";

    public MyOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SCORES);
        db.execSQL(CREATE_TABLE_SAVED);
        db.execSQL(CREATE_TABLE_DICE);
        db.execSQL(CREATE_TABLE_PLAYERS);
        db.execSQL(CREATE_TABLE_WIN);
        db.execSQL(CREATE_TABLE_GAMES);
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_TABLE_SCORES);
        db.execSQL(DROP_TABLE_SAVED);
        db.execSQL(DROP_TABLE_DICE);
        db.execSQL(DROP_TABLE_PLAYERS);
        db.execSQL(DROP_TABLE_WIN);
        db.execSQL(DROP_TABLE_GAMES);
        onCreate(db);
    }
}
