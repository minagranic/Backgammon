package com.example.mina.backgammon;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class Odabir extends AppCompatActivity {
    Model model;
    EditText player1, player2;
    CheckBox ch1, ch2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_odabir);
        player1 = findViewById(R.id.player1EditText);
        player2 = findViewById(R.id.player2EditText);
        ch1 = (CheckBox) findViewById(R.id.is_computer_1);
        ch2 = (CheckBox) findViewById(R.id.is_computer_2);
        if (savedInstanceState == null) {
            model = (Model) getIntent().getExtras().getSerializable("model");
        } else {
            model = (Model) savedInstanceState.getSerializable("model");
            player1.setText(savedInstanceState.getString("player1"));
            player2.setText(savedInstanceState.getString("player2"));
            boolean isCh1 = savedInstanceState.getBoolean("checked1");
            boolean isCh2 = savedInstanceState.getBoolean("checked2");
            ch1.setChecked(isCh1);
            ch2.setChecked(isCh2);
            player1.setEnabled(!isCh1);
            player2.setEnabled(!isCh2);
        }
    }

    public void ComputerChecked(View v) {
        if (v == findViewById(R.id.is_computer_1)) {
            if (((CheckBox) v).isChecked()) {
                player1.setEnabled(false);
            } else {
                player1.setEnabled(true);
            }
        } else if (v == findViewById(R.id.is_computer_2)) {
            if (((CheckBox) v).isChecked()) {
                player2.setEnabled(false);
            } else {
                player2.setEnabled(true);
            }
        }
    }


    public void play(View view) {
        if (ch1.isChecked()) {
            model.setPlayer1Type(Model.PlayerType.COMPUTER);
            model.setPlayer1Name("WALL·E");
        } else {
            model.setPlayer1Type(Model.PlayerType.PLAYER);
            model.setPlayer1Name(player1.getText().toString());
        }
        if (ch2.isChecked()) {
            model.setPlayer2Type(Model.PlayerType.COMPUTER);
            model.setPlayer2Name("EVE");
        } else {
            model.setPlayer2Type(Model.PlayerType.PLAYER);
            model.setPlayer2Name(player2.getText().toString());
        }
        model.newGame();
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    model.deleteLoad(Odabir.this);
                    for (int i = 1; i <= 25; i++) {
                        model.saveGameStub(i, Odabir.this);
                    }
                    model.savePlayers(Odabir.this);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        }.execute();
        Intent intent = new Intent(this, Tabla.class);
        intent.putExtra("model", model);
        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("model", model);
        outState.putString("player1", player1.getText().toString());
        outState.putString("player2", player2.getText().toString());
        outState.putBoolean("checked1", ch1.isChecked());
        outState.putBoolean("checked2", ch2.isChecked());
    }
}
