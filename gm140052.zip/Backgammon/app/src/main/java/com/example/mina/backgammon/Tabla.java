package com.example.mina.backgammon;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.mina.backgammon.beans.Stub;
import com.example.mina.backgammon.beans.Zeton;

public class Tabla extends AppCompatActivity implements View.OnTouchListener {
    private SensorManager sm;
    private float acelVal; // current acceleration including gravity
    private float acelLast; // last acceleration including gravity
    private float shake; // acceleration apart from gravity
    static TableImageView tableImageView;
    static Model model;
    boolean shaking = false;
    static MediaPlayer mp;
    public static boolean drawDice = false;
    public static boolean computerPlays = false;

    AI ai;
    Stub pocetni_stub, krajnji_stub;
    double d, dx, dy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //Remove notification bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (savedInstanceState == null) {
            model = (Model) getIntent().getExtras().getSerializable("model");
        } else {
            model = (Model) savedInstanceState.getSerializable("model");
        }
        setContentView(R.layout.activity_tabla);
        tableImageView = findViewById(R.id.tabla_image_view);

        if (model.getPlayer2Type() == Model.PlayerType.COMPUTER) {
            model.setAi2(new AI());
            model.getAi2().setModel(model);
        }
        if (model.getPlayer1Type() == Model.PlayerType.COMPUTER) {
            model.setAi1(new AI());
            model.getAi1().setModel(model);
            computerPlays = true;
            computerMove();
        }

        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sm.registerListener(sensorListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        shake = 0.00f;
        acelVal = SensorManager.GRAVITY_EARTH;
        acelLast = SensorManager.GRAVITY_EARTH;
        tableImageView.setOnTouchListener(this);
        tableImageView.invalidate();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("model", model);
    }

    private final SensorEventListener sensorListener = new SensorEventListener() {

        public void onSensorChanged(SensorEvent se) {
            if (Tabla.this.hasWindowFocus()) {
                float x = se.values[0];
                float y = se.values[1];
                float z = se.values[2];
                acelLast = acelVal;
                acelVal = (float) Math.sqrt((double) (x * x + y * y + z * z));
                float delta = Math.abs(acelVal - acelLast);
                // shake_moments[count++ % BUFFER_SIZE] = delta;
                // for (float d : shake_moments) {
                //    shake += d;
                // }
                shake = shake * 0.7f + delta; // perform low-cut filter
                if (model.getFaza() == Model.Faza.BACANJE_KOCKICE) {
                    if ((shake > model.getUpperThreshold()) && !shaking) {
                        shaking = true;
                        //Toast toast = Toast.makeText(getApplicationContext(), "DO NOT SHAKE ME", Toast.LENGTH_SHORT);
                        //toast.show();
                        mp = MediaPlayer.create(getApplicationContext(), R.raw.shake);
                        mp.start();
                    } else if ((shake < ((double) model.getUpperThreshold() / model.getScale())) && shaking) {
                        model.rollDice();
                        drawDice = true;
                        model.setFaza(Model.Faza.POMERANJE);
                        tableImageView.invalidate();
                        MyAsyncTask myAsyncTask = new MyAsyncTask();
                        myAsyncTask.execute(false);
                        (new AsyncTask<Void, Void, Void>() {
                            @Override
                            protected Void doInBackground(Void... voids) {
                                model.saveGameDice(Tabla.this);
                                model.savePlayers(Tabla.this);
                                if (!model.morePossibleMoves() && !(model.canBearOff() && model.josKockica())) {
                                    model.nextTurn(Tabla.this);
                                }
                                return null;
                            }
                        }).execute();
                        // Toast toast = Toast.makeText(getApplicationContext(), "OK THANKS", Toast.LENGTH_SHORT);
                        //toast.show();
                        shaking = false;
                        mp.stop();
                        boolean morepm = model.morePossibleMoves();
                        boolean josKockica = model.josKockica();
                        boolean done = !morepm && !model.canBearOff();
                        if (done) {
                            model.nextTurn(Tabla.this);
                            if (model.getTurn() == 0) {
                                if (model.getPlayer1Type() == Model.PlayerType.COMPUTER) {
                                    computerPlays = true;
                                    computerMove();
                                } else {
                                    computerPlays = false;
                                }
                            } else {
                                if (model.getPlayer2Type() == Model.PlayerType.COMPUTER) {
                                    computerPlays = true;
                                    computerMove();
                                } else {
                                    computerPlays = false;
                                }
                            }
                        }
                    }
                }
            }
        }

        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        boolean end = false;
        boolean more_left = true;
        if (computerPlays)
            return true;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (model.getFaza() == Model.Faza.BACANJE_KOCKICE) {
                    Toast t = Toast.makeText(this, "Bacite kockicu prvo!", Toast.LENGTH_SHORT);
                    t.show();
                } else if (model.getFaza() == Model.Faza.POMERANJE) {
                    if (!model.josKockica()) {
                        model.nextTurn(Tabla.this);
                    } else {
                        if (model.getDrzim() == null) {
                            int s = tableImageView.chooseToken(event);
                            if (s >= 0) {
                                model.possibleMoves(s);
                                tableImageView.invalidate();
                            }
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (model.getFaza() == Model.Faza.POMERANJE) {
                    if (model.getDrzim() != null) {
                        model.setDrzim_x(event.getX());
                        model.setDrzim_y(event.getY());
                        tableImageView.invalidate();
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                if (model.getFaza() == Model.Faza.POMERANJE) {
                    if (model.getDrzim() != null) {
                        more_left = tableImageView.releaseToken(event);
                        model.removePossible();
                        tableImageView.invalidate();
                        new AsyncTask<Void, Void, Void>() {
                            @Override
                            protected Void doInBackground(Void... voids) {
                                model.saveGameDice(Tabla.this);
                                return null;
                            }
                        }.execute();
                        end = model.isTheEnd();
                        if (end) {
                            theEnd();
                        }
                    }
                    boolean morepm = model.morePossibleMoves();
                    boolean done = !end && !morepm && !model.canBearOff();
                    if (done) {
                        model.nextTurn(Tabla.this);
                        if (model.getTurn() == 0) {
                            if (model.getPlayer1Type() == Model.PlayerType.COMPUTER) {
                                computerPlays = true;
                                computerMove();
                            } else {
                                computerPlays = false;
                            }
                        } else {
                            if (model.getPlayer2Type() == Model.PlayerType.COMPUTER) {
                                computerPlays = true;
                                computerMove();
                            } else {
                                computerPlays = false;
                            }
                        }
                    }
                }
                break;
        }
        return true;
    }

    @SuppressLint("StaticFieldLeak")
    public void computerMove() {
        if (model.getTurn() == 0) {
            ai = model.getAi1();
        } else {
            ai = model.getAi2();
        }

        MyComputerAsyncTask mat1 = new MyComputerAsyncTask();
        mat1.execute();

    }

    public void nextTurn() {
        model.nextTurn(Tabla.this);
        if (model.getTurn() == 0) {
            if (model.getPlayer1Type() == Model.PlayerType.COMPUTER) {
                computerPlays = true;
                computerMove();
            } else {
                computerPlays = false;
            }
        } else {
            if (model.getPlayer2Type() == Model.PlayerType.COMPUTER) {
                computerPlays = true;
                computerMove();
            } else {
                computerPlays = false;
            }
        }
    }

    public void theEnd() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                Intent intent = new Intent(Tabla.this, EndActivity.class);
                int poeni = model.poeni();
                model.setAi1(null);
                model.setAi2(null);
                intent.putExtra("poeni", poeni);
                intent.putExtra("model", model);
                model.saveWinGame(Tabla.this);
                startActivity(intent);
                return null;
            }
        }.execute();
    }

    class MyAsyncTask extends AsyncTask<Boolean, Void, Void> {

        @Override
        protected Void doInBackground(Boolean... booleans) {
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            try {
                drawDice = !drawDice;
                tableImageView.invalidate();
                if (!drawDice) {
                    model.setFaza(Model.Faza.POMERANJE);
                    if (!(model.morePossibleMoves() || (model.canBearOff() && model.josKockica()))) {
                        model.nextTurn(Tabla.this);
                        if (model.getTurn() == 0) {
                            if (model.getPlayer1Type() == Model.PlayerType.COMPUTER) {
                                computerPlays = true;
                            } else {
                                computerPlays = false;
                            }
                        } else {
                            if (model.getPlayer2Type() == Model.PlayerType.COMPUTER) {
                                computerPlays = true;
                            } else {
                                computerPlays = false;
                            }
                        }
                    }
                } else {
                    if (mp.isPlaying())
                        mp.stop();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class MyComputerAsyncTask extends AsyncTask<Boolean, Void, Void> {
        boolean end;

        @Override
        protected Void doInBackground(Boolean... booleans) {
            try {
                mp = MediaPlayer.create(getApplicationContext(), R.raw.shake);
                mp.start();
                model.rollDice();
                model.setFaza(Model.Faza.BACANJE_KOCKICE);
                drawDice = false;
                // vreme dok se ne zaustave kockice
                Thread.sleep(1000);
                drawDice = true;
                publishProgress();
                // Prikazivanje kockica na ekranu
                Thread.sleep(1500);
                drawDice = false;
                model.setFaza(Model.Faza.POMERANJE);
                if (!(model.morePossibleMoves() || (model.canBearOff()))) {

                } else {
                    publishProgress();
                    // igranje
                    end = false;
                    while (!end && (model.morePossibleMoves() || model.canBearOff())) {
                        ai.odigraj();

                        pocetni_stub = ai.getPocetni();
                        krajnji_stub = ai.getKrajnji();
                        int index1 = model.getStubovi().indexOf(pocetni_stub);
                        if (index1 == -1)
                            index1 = 24;
                        int index2 = model.getStubovi().indexOf(krajnji_stub);
                        double[] coord_poc = tableImageView.zetonXY(index1 + 1, pocetni_stub.size() - 1);
                        double[] coord_krajnji = tableImageView.zetonXY(index2 + 1, krajnji_stub.size());

                        dx = coord_krajnji[0] - coord_poc[0];
                        dy = coord_krajnji[1] - coord_poc[1];
                        d = Math.sqrt(dx * dx + dy * dy);
                        Zeton zeton = pocetni_stub.get(pocetni_stub.size() - 1);
                        int zeton_R = (int) (2 * tableImageView.TOKEN_HALF_LENGHT_COEF * tableImageView.getWidth()
                                * tableImageView.coef);
                        model.setDrzim(zeton);

                        model.setDrzim_x(coord_poc[0] + ((double)zeton_R)/2);
                        model.setDrzim_y(coord_poc[1] + ((double)zeton_R)/2);
                        model.setUzet_sa_stuba(index1 + 1);
                        if (pocetni_stub != krajnji_stub) {
                            Thread.sleep(1000);
                            int refresh = 15;
                            double total = (1000 * d) / tableImageView.getWidth();
                            for (int i = 0; i < total; i += refresh) {
                                Thread.sleep(refresh);
                                model.setDrzim_x(model.getDrzim_x() + dx * refresh / total);
                                model.setDrzim_y(model.getDrzim_y() + dy * refresh / total);
                                publishProgress();
                            }
                            if ((krajnji_stub.size() == 1) && (krajnji_stub.getZetoni().get(0).getBoja() != model.trenutnaBoja())
                                    && (krajnji_stub.getZetoni().get(0).getVidljivost() != Zeton.Vidljivost.POSSIBLE)) {
                                model.hit(krajnji_stub);
                            }
                            krajnji_stub.getZetoni().add(model.getDrzim());
                            model.saveGameStub(index2 + 1, Tabla.this); //TODO
                            if (model.getUzet_sa_stuba() == 25) {
                                model.getBar().getZetoni().remove(model.getDrzim());
                                model.saveGameStub(25, Tabla.this);
                            } else {
                                final int bivsi_index = model.getUzet_sa_stuba();
                                pocetni_stub.getZetoni().remove(model.getDrzim());
                                model.saveGameStub(bivsi_index, Tabla.this);
                            }
                            model.setDrzim(null);
                            int pocetni_index = index1;
                            if (pocetni_index == 24) {
                                //on bar
                                if (model.trenutnaBoja() ==  Zeton.Boja.BELA)
                                    pocetni_index = -1;
                                else
                                    pocetni_index = 24;
                            }
                            int broj_na_kockici = Math.abs(model.getStubovi().indexOf(krajnji_stub)
                                    - pocetni_index);
                            model.removeDie(broj_na_kockici);
                        } else {
                            final int bivsi_index = model.getUzet_sa_stuba();
                            Stub bivsi = model.getStub(bivsi_index);
                            int najblizi_stub = bivsi_index;
                            Stub stub = pocetni_stub;
                            if (model.trenutnaBoja() == Zeton.Boja.BELA) {
                                int temp_stub = najblizi_stub;
                                najblizi_stub = 25 - najblizi_stub;
                                if (model.getKockice()[0] == najblizi_stub
                                        || model.getKockice()[1] == najblizi_stub
                                        || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                        || (model.isNajvisi(najblizi_stub)
                                        && ((model.getKockice()[0] > najblizi_stub)
                                        || (model.getKockice()[1] > najblizi_stub)))) {
                                    najblizi_stub = temp_stub;
                                    najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                    bivsi.getZetoni().remove(model.getDrzim());
                                    AsyncTask<Void, Void, Void> at2 = new AsyncTask<Void, Void, Void>() {
                                        @Override
                                        protected Void doInBackground(Void... voids) {
                                            model.saveGameStub(bivsi_index, Tabla.this);
                                            return null;
                                        }
                                    }.execute();
                                    int start = 25 - bivsi.getId();
                                    for (int j = 6; j >= start; j--) {
                                        if ((model.getKockice()[0] == j) || (model.getKockice()[1] == j)) {
                                            if ((j == start) || (model.isNajvisi(start))) {
                                                model.removeDie(j);
                                                break;
                                            }
                                        }
                                    }
                                }
                            } else {
                                if (model.getKockice()[0] == najblizi_stub
                                        || model.getKockice()[1] == najblizi_stub
                                        || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                        || (model.isNajvisi(najblizi_stub)
                                        && ((model.getKockice()[0] > najblizi_stub) || (model.getKockice()[1] > najblizi_stub)))) {
                                    najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                    bivsi.getZetoni().remove(model.getDrzim());
                                    AsyncTask<Void, Void, Void> at2 = new AsyncTask<Void, Void, Void>() {
                                        @Override
                                        protected Void doInBackground(Void... voids) {
                                            model.saveGameStub(bivsi_index, Tabla.this);
                                            return null;
                                        }
                                    }.execute();
                                    int start = bivsi.getId();
                                    for (int j = 6; j >= start; j--) {
                                        if (((model.getKockice()[0] == j) || (model.getKockice()[1] == j))) {
                                            if ((j == start) || (model.isNajvisi(start))) {
                                                model.removeDie(j);
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        publishProgress();
                        end = model.isTheEnd();
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            if (mp.isPlaying())
                mp.stop();
            tableImageView.invalidate();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            tableImageView.invalidate();
            if (end) {
                theEnd();
            }
            nextTurn();
            if (model.getTurn() == 0) {
                if (model.getPlayer1Type() == Model.PlayerType.COMPUTER) {
                    computerPlays = true;
                } else {
                    computerPlays = false;
                }
            } else {
                if (model.getPlayer2Type() == Model.PlayerType.COMPUTER) {
                    computerPlays = true;
                } else {
                    computerPlays = false;
                }
            }
            if (computerPlays)
                computerMove();
        }

    }

    @Override
    public void onBackPressed() {
        tableImageView = null;
        this.finishAndRemoveTask();
        super.onBackPressed();
    }


}