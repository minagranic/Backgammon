package com.example.mina.backgammon.beans;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Mina on 20-Jan-18.
 */

public class Stub implements Serializable {
    private ArrayList<Zeton> zetoni = new ArrayList<Zeton>();

    private static int posl_id = 0;
    private int id = ++posl_id;

    public ArrayList<Zeton> getZetoni() {
        return zetoni;
    }

    public void setZetoni(ArrayList<Zeton> zetoni) {
        this.zetoni = zetoni;
    }

    public Stub(ArrayList<Zeton> zetoni) {
        this.zetoni = zetoni;
    }

    public Stub() {
    }
    public int size() {return zetoni.size();}
    public Zeton get(int i) {return zetoni.get(i);}
    public void set(int i, Zeton zeton) {zetoni.set(i, zeton);}
    public void add (Zeton zeton) {zetoni.add(zeton);}

    public static int getPosl_id() {
        return posl_id;
    }

    public static void setPosl_id(int posl_id) {
        Stub.posl_id = posl_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Stub(int id) {
        this.id = id;
    }
}
