package com.example.mina.backgammon;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;

public class Settings extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {
    SeekBar seekBar;
    public static final int SEEKBAR_MAX = 20;
    public static final int SEEKBAR_MIN = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(this);
        seekBar.setMax(SEEKBAR_MAX);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        double result = ((double)seekBar.getProgress())*(SEEKBAR_MAX-SEEKBAR_MIN)/SEEKBAR_MAX + SEEKBAR_MIN;
        SharedPreferences pref = getSharedPreferences("PREF",MODE_PRIVATE);
        pref.edit().putInt("shake",(int)result).commit();

    }
}
