package com.example.mina.backgammon.database;

import android.provider.BaseColumns;

/**
 * Created by Mina on 21-Jan-18.
 */

public class DiceEntry implements BaseColumns {
    public static final String TABLE_NAME = "Kockica";
    public static final String COLUMN_NUMBER = "broj";
}
