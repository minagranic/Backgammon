package com.example.mina.backgammon.database;

import android.content.ContentValues;
import android.provider.BaseColumns;

/**
 * Created by Mina on 22-Jan-18.
 */

public class PlayerEntry implements BaseColumns {
    public static final String TABLE_NAME = "Players";
    public static final String COLUMN_PLAYER = "ime";
    public static final String COLUMN_COLOR = "boja";
    public static final String COLUMN_MY_TURN = "mojRed";
}
