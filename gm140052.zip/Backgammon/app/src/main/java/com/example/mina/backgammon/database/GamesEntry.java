package com.example.mina.backgammon.database;

import android.provider.BaseColumns;

/**
 * Created by Mina on 25-Jan-18.
 */
// Za svaku partiju za svaki par
public class GamesEntry implements BaseColumns {
    public static final String TABLE_NAME = "Partije";
    public static final String COLUMN_PAIR_ID = "idPara";
    public static final String COLUMN_POENI = "poeni";
}