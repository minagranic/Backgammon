package com.example.mina.backgammon;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mina.backgammon.beans.Victory;
import com.example.mina.backgammon.database.GamesEntry;
import com.example.mina.backgammon.database.MyOpenHelper;
import com.example.mina.backgammon.database.ScoresEntry;

public class PairScores extends AppCompatActivity {
    Model model;
    MyOpenHelper helper;
    ListView list;
    Victory pair;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_scores);
        if (savedInstanceState == null) {
            model = (Model) getIntent().getExtras().getSerializable("model");
            pair = (Victory) getIntent().getExtras().getSerializable("pair");
        } else {
            model = (Model) savedInstanceState.getSerializable("model");
            pair = (Victory) savedInstanceState.getSerializable("pair");
        }
        helper = new MyOpenHelper(this);
        list = findViewById(R.id.lista_rezultata_par);
        allGames();
    }
    public void allGames() {
        new AsyncTask<Void, Void, Void>() {
            int wins1 = 0;
            int wins2 = 0;
            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    SQLiteDatabase db = helper.getReadableDatabase();
                    String selection = "(" + ScoresEntry.COLUMN_PLAYER1 + "=? AND " + ScoresEntry.COLUMN_PLAYER2 + "=?) OR ("
                            + ScoresEntry.COLUMN_PLAYER1 + "=? AND " + ScoresEntry.COLUMN_PLAYER2 + "=?)";
                    String[] selectionArgs = {pair.getPlayer1Name(),
                            pair.getPlayer2Name(),
                            pair.getPlayer2Name(),
                            pair.getPlayer1Name()};
                    Cursor c = db.query(ScoresEntry.TABLE_NAME, null, selection, selectionArgs, null, null, null);
                    adapter = new MyAdapter();
                    adapter.setContext(PairScores.this);
                    if (c.moveToNext()) {
                        String player1Name = c.getString(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER1));
                        String player2Name = c.getString(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER2));
                        int pairId = c.getInt(c.getColumnIndex(ScoresEntry._ID));
                        String selection1 = GamesEntry.COLUMN_PAIR_ID + "=?";
                        String[] selectionArgs1 = {"" + pairId};
                        //Cursor cX = db.query(GamesEntry.TABLE_NAME, null, null, null, null, null, GamesEntry._ID + " ASC");
                        Cursor c1 = db.query(GamesEntry.TABLE_NAME, null, selection1, selectionArgs1, null, null, GamesEntry._ID + " ASC");
                        while (c1.moveToNext()) {
                            int score1 = c1.getInt(c1.getColumnIndex(GamesEntry.COLUMN_POENI));
                            int score2 = 0;
                            if (score1 < 0) {
                                score2 = -score1;
                                score1 = 0;
                                wins2+=score2;
                            } else {
                                wins1+=score1;
                            }
                            int gameId = c1.getInt(c1.getColumnIndex(GamesEntry._ID));
                            Victory v = new Victory(player1Name, player2Name, score1, score2, pairId, gameId);
                            adapter.getVictories().add(v);
                        }

                        db.close();
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
            @Override
            protected void onPostExecute(Void voiD) {
                try {
                    list.setAdapter(adapter);
                    list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent intent = new Intent(PairScores.this, TableWin.class);
                            intent.putExtra("model", model);
                            intent.putExtra("pair", adapter.getVictories().get(position));
                            startActivity(intent);
                        }
                    });
                    TextView textView = ((TextView) PairScores.this.findViewById(R.id.broj_pobeda));
                    textView.setText(wins1 + ":" + wins2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }.execute();

    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("model", model);
        outState.putSerializable("pair", pair);
    }
}
