package com.example.mina.backgammon;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.example.mina.backgammon.beans.Victory;
import com.example.mina.backgammon.database.MyOpenHelper;

public class TableWin extends AppCompatActivity {
    Model model;
    Victory pair;
    MyOpenHelper helper;
    WinTableImageView table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_win);
        if (savedInstanceState == null) {
            model = (Model) getIntent().getExtras().getSerializable("model");
            pair = (Victory) getIntent().getExtras().getSerializable("pair");
        } else {
            model = (Model) savedInstanceState.getSerializable("model");
            pair = (Victory) savedInstanceState.getSerializable("pair");
        }
        helper = new MyOpenHelper(this);
        table = this.findViewById(R.id.tabla_image_view);
        table.setModel(model);
        loadGame();

    }
    public void loadGame() {
        AsyncTask<Void, Void, Void> asyncTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                model.loadWin(TableWin.this, pair);
                table.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onBackPressed();
                    }
                });
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                table.invalidate();

            }
        }.execute();

    }
    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public Victory getPair() {
        return pair;
    }

    public void setPair(Victory pair) {
        this.pair = pair;
    }

    public MyOpenHelper getHelper() {
        return helper;
    }

    public void setHelper(MyOpenHelper helper) {
        this.helper = helper;
    }
}
