package com.example.mina.backgammon.database;

import android.provider.BaseColumns;

/**
 * Created by Mina on 15-Jan-18.
 */

public class TableEntry implements BaseColumns {
    public static final String TABLE_NAME = "Tabla";
    public static final String COLUMN_FIELD = "polje";
    public static final String COLUMN_COLOR = "boja";
    public static final String COLUMN_COUNT = "broj";
    public static final String TABLE_NAME_WIN = "TablaWin";
    public static final String COLUMN_GAME_ID = "idIgre";
    public static final String COLUMN_PAIR_ID = "idPara";
}
