package com.example.mina.backgammon;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.support.v4.app.ActivityCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.mina.backgammon.beans.Victory;

import java.util.ArrayList;

/**
 * Created by Mina on 02-Feb-18.
 */

public class MyAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Victory> victories = new ArrayList<>();

    @Override
    public int getCount() {
        return victories.size();
    }

    @Override
    public Object getItem(int position) {
        return victories.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup container) {
        if (convertView == null) {
            try {
                Victory v = victories.get(position);
                convertView = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.end_victories, container, false);
                ((TextView) convertView.findViewById(R.id.player1NameTextView)).setText(v.getPlayer1Name());
                ((TextView) convertView.findViewById(R.id.player2NameTextView)).setText(v.getPlayer2Name());
                TextView score1 = convertView.findViewById(R.id.player1ScoreTextView);
                score1.setText(v.getPlayer1Score() + "");
                TextView score2 = convertView.findViewById(R.id.player2ScoreTextView);
                score2.setText(v.getPlayer2Score() + "");
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
        return convertView;
    }

    public ArrayList<Victory> getVictories() {
        return victories;
    }

    public void setVictories(ArrayList<Victory> victories) {
        this.victories = victories;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}
