package com.example.mina.backgammon;

import com.example.mina.backgammon.beans.Stub;
import com.example.mina.backgammon.beans.Zeton;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Mina on 21-Jan-18.
 */

public class AI implements Serializable{
    Model model;
    Stub pocetni, krajnji;
    ArrayList<ArrayList<Stub>> moguci_potezi = new ArrayList<>();
    ArrayList<Stub> pocetni_potezi = new ArrayList<>();

    public void odigraj() {
        moguci_potezi.clear();
        pocetni_potezi.clear();
        Zeton z;
        if (model.onTheBar(model.trenutnaBoja())) {
            boolean found = false;
            for (Zeton zeton : model.getBar().getZetoni()) {
                if (zeton.getBoja() == model.trenutnaBoja()) {
                    found = true;
                    z = zeton;
                    break;
                }
            }
            ArrayList<Stub> stubovi = model.possibleMoves(25);
            if (stubovi.size() > 0) {
                moguci_potezi.add(stubovi);
                pocetni_potezi.add(model.getStub(25));
            }

        } else {
            for (int i = 1; i <= 24; i++) {
                Stub stub = model.getStub(i);
                if (stub.size() > 0 && (stub.get(0).getBoja() == model.trenutnaBoja())) {
                    // moze da odigra ovde nesto
                    ArrayList<Stub> stubovi = model.possibleMoves(i);
                    if (stubovi.size() > 0) {
                        moguci_potezi.add(stubovi);
                        pocetni_potezi.add(stub);
                    }
                }
            }
            if (model.canBearOff()) {
                if (model.trenutnaBoja() == Zeton.Boja.BELA) {
                    for (int i = 24; i >= 19; i--) {
                        int najblizi_stub = i;
                        Stub stub = model.getStub(najblizi_stub);
                        if (stub.size() > 0) {
                            int temp_stub = najblizi_stub;
                            najblizi_stub = 25 - najblizi_stub;
                            if (model.getKockice()[0] == najblizi_stub
                                    || model.getKockice()[1] == najblizi_stub
                                    || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                    || (model.isNajvisi(najblizi_stub)
                                    && ((model.getKockice()[0] > najblizi_stub) || (model.getKockice()[1] > najblizi_stub)))) {
                                pocetni_potezi.add(stub);
                                najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                ArrayList<Stub> moguci = new ArrayList<>();
                                moguci.add(stub);
                                moguci_potezi.add(moguci);
                            }
                        }
                    }
                } else {
                    for (int i = 1; i <= 6; i++) {
                        int najblizi_stub = i;
                        Stub stub = model.getStub(najblizi_stub);
                        if (stub.size() > 0) {
                            if (model.getKockice()[0] == najblizi_stub
                                    || model.getKockice()[1] == najblizi_stub
                                    || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                    || (model.isNajvisi(najblizi_stub)
                                    && ((model.getKockice()[0] > najblizi_stub) || (model.getKockice()[1] > najblizi_stub)))) {
                                pocetni_potezi.add(stub);
                                najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                ArrayList<Stub> moguci = new ArrayList<>();
                                moguci.add(stub);
                                moguci_potezi.add(moguci);
                            }
                        }
                    }
                }
            }
        }
    randomPotez();
}

    public void randomPotez() {
        Random random = new Random();
        int len = moguci_potezi.size();
        int rand = random.nextInt(len);
        ArrayList<Stub> stubovi = moguci_potezi.get(rand);
        pocetni = pocetni_potezi.get(rand);
        len = stubovi.size();
        rand = random.nextInt(len);
        krajnji = stubovi.get(rand);
    }

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public Stub getPocetni() {
        return pocetni;
    }

    public void setPocetni(Stub pocetni) {
        this.pocetni = pocetni;
    }

    public Stub getKrajnji() {
        return krajnji;
    }

    public void setKrajnji(Stub krajnji) {
        this.krajnji = krajnji;
    }

    public ArrayList<ArrayList<Stub>> getMoguci_potezi() {
        return moguci_potezi;
    }

    public void setMoguci_potezi(ArrayList<ArrayList<Stub>> moguci_potezi) {
        this.moguci_potezi = moguci_potezi;
    }

    public ArrayList<Stub> getPocetni_potezi() {
        return pocetni_potezi;
    }

    public void setPocetni_potezi(ArrayList<Stub> pocetni_potezi) {
        this.pocetni_potezi = pocetni_potezi;
    }
}
