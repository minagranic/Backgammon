package com.example.mina.backgammon;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mina.backgammon.beans.Victory;
import com.example.mina.backgammon.database.GamesEntry;
import com.example.mina.backgammon.database.MyOpenHelper;
import com.example.mina.backgammon.database.ScoresEntry;
import com.example.mina.backgammon.database.TableEntry;

import java.util.ArrayList;

public class Scores extends AppCompatActivity {
    ListView list;
    Model model;
    MyOpenHelper helper;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores);
        if (savedInstanceState == null)
            model = (Model) getIntent().getExtras().getSerializable("model");
        else
            model = (Model) savedInstanceState.getSerializable("model");
        adapter = new MyAdapter();
        adapter.setContext(this);
        list = findViewById(R.id.leaderboard);
        loadLeaderboard();
    }

    private void loadLeaderboard() {

        (new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                loadCursor();
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                list.setAdapter(adapter);
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent intent = new Intent(Scores.this, PairScores.class);
                        intent.putExtra("model", model);
                        intent.putExtra("pair", adapter.getVictories().get(position));
                        startActivity(intent);
                    }
                });
            }

        }).execute();

    }

    protected Cursor loadCursor() {
        MyOpenHelper helper = new MyOpenHelper(Scores.this);
        String projection[] = new String[]{ScoresEntry._ID,
                ScoresEntry.COLUMN_PLAYER1, ScoresEntry.COLUMN_PLAYER2};
        SQLiteDatabase db = helper.getReadableDatabase();
        try {
            Cursor c = db.query(ScoresEntry.TABLE_NAME, projection, null, null, null, null, ScoresEntry._ID + " ASC");
            int pairID = 0;
            while (c.moveToNext()) {
                pairID = c.getInt(c.getColumnIndex(ScoresEntry._ID));
                String name1 = c.getString(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER1));
                String name2 = c.getString(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER2));
                adapter.getVictories().add(new Victory(name1, name2, pairID));
            }
            c = db.query(GamesEntry.TABLE_NAME, null, null, null, null, null, GamesEntry.COLUMN_PAIR_ID + " ASC");
            int position = 0;
            while (c.moveToNext()) {
                pairID = c.getInt(c.getColumnIndex(GamesEntry.COLUMN_PAIR_ID));
                Victory v = adapter.getVictories().get(position);
                while (v.getPairId() != pairID) {
                    v = adapter.getVictories().get(++position);
                }
                int score = c.getInt(c.getColumnIndex(GamesEntry.COLUMN_POENI));
                if (score > 0) {
                    v.setPlayer1Score(v.getPlayer1Score() + score);
                } else {
                    v.setPlayer2Score(v.getPlayer2Score() + (-score));
                }
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
