package com.example.mina.backgammon;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.example.mina.backgammon.beans.Stub;
import com.example.mina.backgammon.beans.Zeton;

/**
 * Created by Mina on 19-Jan-18.
 */

public class TableImageView extends android.support.v7.widget.AppCompatImageView {
    Paint paint = new Paint(Color.BLACK);
    static Bitmap tabla, zeton_beli, zeton_crni, zeton_crveni, kocka1, kocka2, kocka3, kocka4, kocka5, kocka6;
    public static final double BORDER_V_COEF = 0.1290628;
    public static final double BORDER_H_COEF = 0.060216231;
    public static final double TOKEN_HALF_LENGHT_COEF = 0.028575;
    private static final double DIE_WIDTH = 0.15;
    private static final double DIE_MIDDLE_DIST = 0.15;
    private Model model;
    private Tabla context = (Tabla) getContext();
    private double zeton_R;
    public double coef = 0.8;

    public void dohvatiSlike() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        options.inDither = false;
        options.inSampleSize = 1;
        options.inScaled = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        tabla = BitmapFactory.decodeResource(getResources(), R.drawable.backgammon_board, options);
        zeton_beli = BitmapFactory.decodeResource(getResources(), R.drawable.chip_white, options);
        zeton_crni = BitmapFactory.decodeResource(getResources(), R.drawable.chip_black, options);
        zeton_crveni = BitmapFactory.decodeResource(getResources(), R.drawable.chip_red, options);
        kocka1 = BitmapFactory.decodeResource(getResources(), R.drawable.kocka1, options);
        kocka2 = BitmapFactory.decodeResource(getResources(), R.drawable.kocka2, options);
        kocka3 = BitmapFactory.decodeResource(getResources(), R.drawable.kocka3, options);
        kocka4 = BitmapFactory.decodeResource(getResources(), R.drawable.kocka4, options);
        kocka5 = BitmapFactory.decodeResource(getResources(), R.drawable.kocka5, options);
        kocka6 = BitmapFactory.decodeResource(getResources(), R.drawable.kocka6, options);
    }

    public TableImageView(Context context) {
        super(context);
        dodatno();
    }

    public TableImageView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        dodatno();
    }

    public TableImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        dodatno();
    }

    private void dodatno() {
        model = ((Tabla) context).getModel();
        dohvatiSlike();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        zeton_R = (int) (2 * TOKEN_HALF_LENGHT_COEF * getWidth() * coef);
        try {
            Rect r_table = new Rect(0, 0, getWidth(), getHeight());
            canvas.drawBitmap(tabla, null, r_table, paint);
            crtajPostavku(canvas);
            if (((Tabla) getContext()).drawDice) {
                drawBigDice(canvas);
            } else {
                try {
                    if (model.getKockice()[0] > 0) {
                        double width = getWidth();
                        Rect k1 = new Rect((int) (width - TOKEN_HALF_LENGHT_COEF * 2 * width - 50),
                                (int) (getHeight() / 2 - TOKEN_HALF_LENGHT_COEF * 2 * width),
                                (int) (width - 50),
                                (int) (getHeight() / 2));
                        Bitmap kocka = getDieBitmap(context.model.getKockice()[0]);
                        canvas.drawBitmap(kocka, null, k1, paint);
                    }
                    if (model.getKockice()[1] > 0) {
                        double width = getWidth();
                        Rect k1 = new Rect((int) (width - TOKEN_HALF_LENGHT_COEF * 2 * width - 50),
                                (int) (getHeight() / 2),
                                (int) (width - 50),
                                (int) (getHeight() / 2 + TOKEN_HALF_LENGHT_COEF * 2 * width));
                        Bitmap kocka = getDieBitmap(context.model.getKockice()[1]);
                        canvas.drawBitmap(kocka, null, k1, paint);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (model.getDrzim() != null) {
                Rect rect = new Rect((int) (model.getDrzim_x() - zeton_R / 2),
                        (int) (model.getDrzim_y() - zeton_R / 2),
                        (int) (model.getDrzim_x() + zeton_R / 2),
                        (int) (model.getDrzim_y() + zeton_R / 2));
                canvas.drawBitmap((model.getDrzim().getBoja() == Zeton.Boja.BELA) ? zeton_beli : zeton_crni, null, rect, paint);
            }
            int drawn = 0;
            for (int i = 0; i < model.getBar().size(); i++) {
                Zeton z = model.getBar().get(i);
                if (z.getBoja() == Zeton.Boja.CRNA) {
                    if ((model.getDrzim() == null) || (model.getDrzim() != z)) {
                        Rect rect = new Rect((int) (getWidth() / 2 - zeton_R / 2),
                                (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R - zeton_R / 2),
                                (int) (getWidth() / 2 + zeton_R / 2),
                                (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R + zeton_R / 2));
                        canvas.drawBitmap(zeton_crni, null, rect, paint);
                    }
                    drawn++;
                }
            }
            for (int i = 0; i < model.getBar().size(); i++) {
                Zeton z = model.getBar().get(i);
                if ((z.getBoja() == Zeton.Boja.BELA)) {
                    if ((model.getDrzim() == null) || (model.getDrzim() != z)) {
                        Rect rect = new Rect((int) (getWidth() / 2 - zeton_R / 2),
                                (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R - zeton_R / 2),
                                (int) (getWidth() / 2 + zeton_R / 2),
                                (int) (getHeight() / 2 - (model.getBar().size() / 2 - drawn) * zeton_R + zeton_R / 2));
                        canvas.drawBitmap(zeton_beli, null, rect, paint);
                    }
                    drawn++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void crtajPostavku(Canvas canvas) {
        try {

            Rect rect;
            double upper_left_x = 0;
            double upper_left_y = 0;
            for (int i = 1; i <= 24; i++) {
                Stub stub = model.getStub(i);
                for (int j = 0; j < stub.size(); j++) {
                    Zeton zeton = stub.getZetoni().get(j);
                    if ((model.getDrzim() == null) || (model.getDrzim() != zeton)) {
                        double[] xy = zetonXY(i, j);
                        upper_left_x = xy[0];
                        upper_left_y = xy[1];
                        rect = new Rect((int) upper_left_x, (int) upper_left_y, (int) (upper_left_x + zeton_R), (int) (upper_left_y + zeton_R));
                        Bitmap b;
                        if (zeton.getVidljivost() == Zeton.Vidljivost.POSSIBLE) {
                            b = zeton_crveni;
                        } else if (zeton.getBoja() == Zeton.Boja.BELA) {
                            b = zeton_beli;
                        } else {
                            b = zeton_crni;
                        }
                        canvas.drawBitmap(b, null, rect, paint);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public double[] zetonXY(int i, int j) {
        double upper_left_x = 0, upper_left_y = 0;
        double width = getWidth();
        double height = getHeight();
        double stub_w = (zeton_R / coef);

        if (i <= 6) {
            upper_left_x = width - BORDER_V_COEF * width - i * stub_w;
            upper_left_y = height - BORDER_H_COEF * height - zeton_R - j * zeton_R;
        } else if (i <= 12) {
            upper_left_x = BORDER_V_COEF * width + (12 - i) * stub_w;
            upper_left_y = height - BORDER_H_COEF * height - zeton_R - j * zeton_R;
        } else if (i <= 18) {
            upper_left_x = BORDER_V_COEF * width + (i - 13) * stub_w;
            upper_left_y = BORDER_H_COEF * height + (j) * zeton_R;
        } else if (i <= 24) {
            upper_left_x = width - BORDER_V_COEF * width - stub_w - (24 - i) * stub_w;
            upper_left_y = BORDER_H_COEF * height + (j) * zeton_R;
        } else if (i == 25) {
            upper_left_x = width / 2;
            upper_left_y = height / 2;
        }

        double[] xy = new double[2];
        xy[0] = upper_left_x;
        xy[1] = upper_left_y;
        return xy;

    }


    public void drawBigDice(Canvas canvas) {
        try {
            double width = getWidth();
            Rect k1 = new Rect((int) (width / 2 - DIE_MIDDLE_DIST * width - DIE_WIDTH * width),
                    (int) (getHeight() / 2 - DIE_WIDTH * width / 2),
                    (int) (width / 2 - DIE_MIDDLE_DIST * width),
                    (int) (getHeight() / 2 + DIE_WIDTH * width / 2));
            Bitmap kocka = getDieBitmap(context.model.getKockice()[0]);
            canvas.drawBitmap(kocka, null, k1, paint);
            Rect k2 = new Rect((int) (width / 2 + DIE_MIDDLE_DIST * width),
                    (int) (getHeight() / 2 - DIE_WIDTH * width / 2),
                    (int) (width / 2 + DIE_MIDDLE_DIST * width + DIE_WIDTH * width),
                    (int) (getHeight() / 2 + DIE_WIDTH * width / 2));
            kocka = getDieBitmap(context.model.getKockice()[1]);
            canvas.drawBitmap(kocka, null, k2, paint);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Bitmap getDieBitmap(int number) {
        Bitmap b = null;
        switch (number) {
            case 1:
                b = kocka1;
                break;
            case 2:
                b = kocka2;
                break;
            case 3:
                b = kocka3;
                break;
            case 4:
                b = kocka4;
                break;
            case 5:
                b = kocka5;
                break;
            case 6:
                b = kocka6;
                break;
        }
        return b;
    }

    public int chooseToken(MotionEvent event) {
        if (model.onTheBar(model.trenutnaBoja())) {
            if ((event.getX() > getWidth() / 2 * 0.9) && (event.getX() < getWidth() / 2 * 1.1)) {
                for (Zeton zeton : model.getBar().getZetoni()) {
                    if (zeton.getBoja() == model.trenutnaBoja()) {
                        model.setDrzim(zeton);
                        model.setDrzim_x(event.getX());
                        model.setDrzim_y(event.getY());
                        model.setUzet_sa_stuba(25);
                        return 25;
                    }
                }
            }
        } else {
            int najblizi_stub = najbliziStub(event);
            if ((najblizi_stub > 0) && (najblizi_stub < 25)) {
                Stub stub = model.getStub(najblizi_stub);
                if (model.canBearOff() && (stub.size()>0) &&
                        (model.trenutnaBoja() == stub.get(0).getBoja()) && model.josKockica()) {
                    if (stub.size() > 0) {
                        if (model.trenutnaBoja() == Zeton.Boja.BELA) {
                            int temp_stub = najblizi_stub;
                            najblizi_stub = 25 - najblizi_stub;
                            if (model.getKockice()[0] == najblizi_stub
                                    || model.getKockice()[1] == najblizi_stub
                                    || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                    || model.isNajvisi(najblizi_stub)) {
                                model.setDrzim(stub.get(stub.size() - 1));
                                najblizi_stub = temp_stub;
                                najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                model.setUzet_sa_stuba(najblizi_stub);
                                return najblizi_stub;
                            } else {
                                najblizi_stub = temp_stub;
                            }
                        } else {
                            if (model.getKockice()[0] == najblizi_stub
                                    || model.getKockice()[1] == najblizi_stub
                                    || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                    || model.isNajvisi(najblizi_stub)) {
                                model.setDrzim(stub.get(stub.size() - 1));
                                najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                model.setUzet_sa_stuba(najblizi_stub);
                                return najblizi_stub;
                            }
                        }
                    }
                }
                if ((stub != null) && (stub.size() > 0)) {
                    // nije prazan stub
                    Zeton zeton = stub.getZetoni().get(stub.size() - 1);
                    if (zeton.getBoja() == model.trenutnaBoja()) {
                        // na vrhu je zeton njegov
                        model.setDrzim(zeton);
                        najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                        model.setUzet_sa_stuba(najblizi_stub);
                        return najblizi_stub;
                    }
                }
            }
        }
        return -1000;
    }

    public boolean releaseToken(MotionEvent event) {
        boolean more_left = true;
        if (model.getDrzim() != null) {
            final int najbliziStub = najbliziStub(event);
            if (najbliziStub >= 0) {
                Stub stub = model.getStub(najbliziStub);
                if (najbliziStub != model.getUzet_sa_stuba()) {
                    if (stub.size() > 0) {
                        if (stub.get(stub.size() - 1).getVidljivost() == Zeton.Vidljivost.POSSIBLE) {
                            if ((stub.size() >= 1) || (stub.getZetoni().get(0).getBoja() == model.trenutnaBoja()) ||
                                    stub.size() <= 2) {
                                Zeton crveni = stub.get(stub.size() - 1);
                                int odigrano = crveni.getOdigrano();
                                stub.getZetoni().remove(crveni);
                                if ((stub.size() == 1) && (stub.getZetoni().get(0).getBoja() != model.trenutnaBoja())) {
                                    model.hit(stub);
                                }
                                stub.getZetoni().add(model.getDrzim());
                                AsyncTask<Void, Void, Void> at = new AsyncTask<Void, Void, Void>() {
                                    @Override
                                    protected Void doInBackground(Void... voids) {
                                        model.saveGameStub(najbliziStub, context);
                                        return null;
                                    }
                                }.execute();
                                if (model.getUzet_sa_stuba() == 25) {
                                    model.getBar().getZetoni().remove(model.getDrzim());
                                    AsyncTask<Void, Void, Void> at1 = new AsyncTask<Void, Void, Void>() {
                                        @Override
                                        protected Void doInBackground(Void... voids) {
                                            model.saveGameStub(25, context);
                                            return null;
                                        }
                                    }.execute();
                                } else {
                                    final int bivsi_index = model.getUzet_sa_stuba();
                                    Stub bivsi = model.getStub(bivsi_index);
                                    bivsi.getZetoni().remove(model.getDrzim());
                                    AsyncTask<Void, Void, Void> at2 = new AsyncTask<Void, Void, Void>() {
                                        @Override
                                        protected Void doInBackground(Void... voids) {
                                            model.saveGameStub(bivsi_index, context);
                                            return null;
                                        }
                                    }.execute();
                                }
                                more_left = model.removeDie(odigrano);
                            }
                        }
                    }
                } else if (model.canBearOff() && model.josKockica()) {
                    if (najbliziStub == model.getUzet_sa_stuba()) {
                        final int bivsi_index = model.getUzet_sa_stuba();
                        Stub bivsi = model.getStub(bivsi_index);
                        int najblizi_stub = bivsi_index;
                        stub = bivsi;
                        if (model.trenutnaBoja() == Zeton.Boja.BELA) {
                            int temp_stub = najblizi_stub;
                            najblizi_stub = 25 - najblizi_stub;
                            if (model.getKockice()[0] == najblizi_stub
                                    || model.getKockice()[1] == najblizi_stub
                                    || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                    || (model.isNajvisi(najblizi_stub)
                                    && ((model.getKockice()[0] >najblizi_stub)
                                    || (model.getKockice()[1] >najblizi_stub)))) {
                                najblizi_stub = temp_stub;
                                najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                bivsi.getZetoni().remove(model.getDrzim());
                                AsyncTask<Void, Void, Void> at2 = new AsyncTask<Void, Void, Void>() {
                                    @Override
                                    protected Void doInBackground(Void... voids) {
                                        model.saveGameStub(bivsi_index, context);
                                        return null;
                                    }
                                }.execute();
                                int start = 25 - bivsi.getId();
                                for (int j = 6; j >= start; j--) {
                                    if ((model.getKockice()[0] == j) || (model.getKockice()[1] == j)) {
                                        if ((j == start) || (model.isNajvisi(start))) {
                                            more_left = model.removeDie(j);
                                            break;
                                        }
                                    }
                                }
                            }
                        } else {
                            if (model.getKockice()[0] == najblizi_stub
                                    || model.getKockice()[1] == najblizi_stub
                                    || (model.getKockice()[0] + model.getKockice()[1]) == najblizi_stub
                                    ||  (model.isNajvisi(najblizi_stub)
                                    && ((model.getKockice()[0] >najblizi_stub) || (model.getKockice()[1] >najblizi_stub)))){
                                najblizi_stub = (najblizi_stub > 24) ? 24 : najblizi_stub;
                                bivsi.getZetoni().remove(model.getDrzim());
                                AsyncTask<Void, Void, Void> at2 = new AsyncTask<Void, Void, Void>() {
                                    @Override
                                    protected Void doInBackground(Void... voids) {
                                        model.saveGameStub(bivsi_index, context);
                                        return null;
                                    }
                                }.execute();
                                int start = bivsi.getId();
                                for (int j = 6; j >= start; j--) {
                                    if (((model.getKockice()[0] == j) || (model.getKockice()[1] == j))) {
                                        if ((j == start) || (model.isNajvisi(start))) {
                                            more_left = model.removeDie(j);
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                    }
                    more_left = model.josKockica();
                }
                model.setDrzim(null);
                model.setDrzim_x(0);
                model.setDrzim_y(0);
                invalidate();
            }
        }
        return more_left;
    }

    private int najbliziStub(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        float width = getWidth();
        float height = getHeight();
        int stub_ind = -1000;
        if (y < height / 2) {
            // gornja polovina ekrana
            if (x < width / 2) {
                // 3. kv
                if ((x > BORDER_V_COEF * width * 0.9)) {
                    stub_ind = (int) Math.floor((x - BORDER_V_COEF * width) / (2 * TOKEN_HALF_LENGHT_COEF * width)) + 13;
                }
            } else {
                // 4. kv
                if ((x < width - BORDER_V_COEF * width * 0.9)) {
                    stub_ind = 6 - (int) Math.floor((width - x - BORDER_V_COEF * width) / (2 * TOKEN_HALF_LENGHT_COEF * width)) + 18;
                }
            }
        } else {
            // donja polovina ekrana
            if (x < width / 2) {
                // 2. kv
                if ((x > BORDER_V_COEF * width * 0.9)) {
                    stub_ind = 6 - (int) Math.floor((x - BORDER_V_COEF * width) / (2 * TOKEN_HALF_LENGHT_COEF * width)) + 6;
                }

            } else {
                // 1. kv
                if ((x < width - BORDER_V_COEF * width * 0.9)) {
                    stub_ind = (int) Math.floor((width - x - BORDER_V_COEF * width) / (2 * TOKEN_HALF_LENGHT_COEF * width)) + 1;//      6 - (int) Math.floor((x - width / 2 - BORDER_V_COEF * width) / (2 * TOKEN_HALF_LENGHT_COEF));
                }
            }
        }
        return stub_ind;
    }
}
