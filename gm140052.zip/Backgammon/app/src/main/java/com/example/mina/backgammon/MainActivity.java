package com.example.mina.backgammon;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import com.example.mina.backgammon.database.MyOpenHelper;
import com.example.mina.backgammon.database.TableEntry;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    Model model;
    boolean imaLoad = false;
    private static final int REQUEST_READ_EXTERNAL_STORAGE = 1;
    private static final int REQUEST_WRITE_EXTERNAL_STORAGE = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        model = new Model();
        SharedPreferences pref = getPreferences(MODE_PRIVATE);
        int shaky = pref.getInt("shake",15);
        model.setUpperThreshold(shaky);
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_EXTERNAL_STORAGE);
        }
        // TODO: proveri load
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_READ_EXTERNAL_STORAGE);
        } else {
            loadGameExists();
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent settings = new Intent(MainActivity.this, Settings.class);
            startActivity(settings);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_manage) {
            Intent settings = new Intent(MainActivity.this, Settings.class);
            startActivity(settings);
        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_READ_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadGameExists();
            }
        }
        if (requestCode == REQUEST_WRITE_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadGameExists();
            }
        }
    }

    private void loadGameExists() {
        try {
            (new AsyncTask<Void, Void, Cursor>() {

                @Override
                protected Cursor doInBackground(Void... params) {
                    Cursor c = loadCursor();
                    return c;
                }

                @Override
                protected void onPostExecute(Cursor result) {
                    super.onPostExecute(result);
                    if (!result.moveToNext()) {
                        Button b = MainActivity.this.findViewById(R.id.load_game_button);
                        b.setEnabled(false);
                        b.setClickable(false);
                        //b.getBackground().setColorFilter(Color.GRAY, PorterDuff.Mode.MULTIPLY);
                    }
                    result.close();
                }

            }).execute();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    protected Cursor loadCursor() {
        try {
            MyOpenHelper helper = new MyOpenHelper(MainActivity.this);
            String projection[] = new String[]{TableEntry._ID,
                    TableEntry.COLUMN_FIELD, TableEntry.COLUMN_COLOR, TableEntry.COLUMN_COUNT};
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor c = null;
            try {
                c = db.query(TableEntry.TABLE_NAME, projection, null, null, null, null, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return c;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void newGame(View view) {
        //TODO: mozda i pitaj da li ste sigurni da se obrise
        model = new Model();
        SharedPreferences pref = getSharedPreferences("PREF",MODE_PRIVATE);
        int shaky = pref.getInt("shake",15);
        model.setUpperThreshold(shaky);
        Intent intent = new Intent(MainActivity.this, Odabir.class);
        intent.putExtra("model", model);
        startActivity(intent);

    }

    public void loadGame(View view) {
        model = new Model();
        SharedPreferences pref = getSharedPreferences("PREF",MODE_PRIVATE);
        int shaky = pref.getInt("shake",15);
        model.setUpperThreshold(shaky);
        AsyncTask<Void, Void, Void> asyncTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                model.loadGame(MainActivity.this);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Intent intent = new Intent(MainActivity.this, Tabla.class);
                intent.putExtra("model", model);
                startActivity(intent);

            }
        }.execute();

    }

    public void viewScores(View view) {
        Intent intent = new Intent(this, Scores.class);
        intent.putExtra("model", model);
        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("model", model);
        outState.putBoolean("imaLoad", imaLoad);
    }
}
