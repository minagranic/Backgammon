package com.example.mina.backgammon;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;

import com.example.mina.backgammon.beans.Stub;
import com.example.mina.backgammon.beans.Victory;
import com.example.mina.backgammon.beans.Zeton;
import com.example.mina.backgammon.database.DiceEntry;
import com.example.mina.backgammon.database.GamesEntry;
import com.example.mina.backgammon.database.MyOpenHelper;
import com.example.mina.backgammon.database.PlayerEntry;
import com.example.mina.backgammon.database.ScoresEntry;
import com.example.mina.backgammon.database.TableEntry;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Mina on 15-Jan-18.
 */

public class Model implements Serializable {
    public enum PlayerType {
        PLAYER,
        COMPUTER
    }

    public enum Faza {
        BACANJE_KOCKICE,
        POMERANJE
    }

    private int upperThreshold = 15;
    private double scale = 4;
    private int poeni = 0;
    private ArrayList<Stub> stubovi = new ArrayList();
    private PlayerType player1Type = PlayerType.PLAYER, player2Type = PlayerType.PLAYER;
    private String player1Name = "", player2Name = "";
    private int[] kockice = new int[4];
    private int turn = 0;
    private Faza faza = Faza.BACANJE_KOCKICE;
    private ArrayList<Stub> moguci_stubovi = new ArrayList<>();
    private int uzet_sa_stuba = 0;
    private double drzim_x = 0, drzim_y = 0;
    private Zeton drzim = null;
    private Stub bar = new Stub();
    private AI ai1, ai2;

    public void rollDice() {
        Random r = new Random();
        int int1 = r.nextInt(6) + 1;
        int int2 = r.nextInt(6) + 1;
        kockice[0] = int1;
        kockice[1] = int2;
        if (int1 == int2) {
            kockice[2] = kockice[3] = int1;
        } else {
            kockice[2] = kockice[3] = 0;
        }
    }

    public void deleteLoad(Context context) {
        MyOpenHelper helper = new MyOpenHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        db.delete(TableEntry.TABLE_NAME, null, null);
        db.delete(DiceEntry.TABLE_NAME, null, null);
        db.delete(PlayerEntry.TABLE_NAME, null, null);
        db.close();
    }

    public void newGame() {
        for (Stub stub : stubovi)
            stub.getZetoni().clear();

        pravaPostavka();
        //bearOffTest();
    }

    public void pravaPostavka() {
        postaviStub(1, 2, Zeton.Boja.BELA);
        postaviStub(6, 5/*1*/, Zeton.Boja.CRNA);
        postaviStub(8, 3, Zeton.Boja.CRNA);
        postaviStub(12, 5, Zeton.Boja.BELA);
        postaviStub(13, 5, Zeton.Boja.CRNA);
        postaviStub(17, 3, Zeton.Boja.BELA);
        postaviStub(19, 5/*1*/, Zeton.Boja.BELA);
        postaviStub(24, 2, Zeton.Boja.CRNA);

    }

    public void bearOffTest() {
        postaviStub(1, 2, Zeton.Boja.CRNA);
       // postaviStub(3, 5/*1*/, Zeton.Boja.CRNA);
      //  postaviStub(5, 3, Zeton.Boja.CRNA);
        postaviStub(6, 1, Zeton.Boja.CRNA);
        postaviStub(19, 1, Zeton.Boja.BELA);
        postaviStub(21, 3, Zeton.Boja.BELA);
        postaviStub(23, 5/*1*/, Zeton.Boja.BELA);
        postaviStub(24, 2, Zeton.Boja.BELA);

    }

    public void postaviStub(int index_stuba, int broj_zetona, Zeton.Boja boja) {
        Stub stub = getStub(index_stuba);
        int poc = stub.size();
        for (int i = poc; i < broj_zetona + poc; i++) {
            stub.getZetoni().add(new Zeton(boja));
        }
    }

    public Stub getStub(int index) {
        if (index == 25)
            return bar;
        return stubovi.get(index - 1);
    }

    // Za BearOff, da li moze da se skine neki sa njega
    public boolean isNajvisi(int stub) {
        if (trenutnaBoja() == Zeton.Boja.BELA) {
            stub = 25 - stub;
            for (int i = stub - 1; i >= 19; i--) {
                if ((getStub(i).size() > 0) && (getStub(i).get(0).getBoja() == trenutnaBoja()))
                    return false;
            }
            return true;
        } else {
            for (int i = stub + 1; i <= 6; i++) {
                if ((getStub(i).size() > 0) && (getStub(i).get(0).getBoja() == trenutnaBoja()))
                    return false;
            }
            return true;
        }
    }

    public Model() {
        for (int i = 0; i < 24; i++) {
            stubovi.add(new Stub(i + 1));
        }
    }

    public boolean morePossibleMoves() {
        ArrayList<Stub> pos_stubovi;
        if (!josKockica())
            return false;
        if (onTheBar(trenutnaBoja())) {
            pos_stubovi = possibleMoves((turn == 0) ? 0 : 25);
            if (pos_stubovi.size() > 0)
                return true;
        } else {
            for (Stub stub : stubovi) {
                if (stub.size() > 0) {
                    if (stub.get(0).getBoja() == trenutnaBoja()) {
                        pos_stubovi = possibleMoves(stubovi.indexOf(stub) + 1);
                        if ((pos_stubovi.size() > 0) || (canBearOff()))
                            return true;
                    }
                }
            }
        }
        moguci_stubovi.clear();
        return false;
    }
    public ArrayList<Stub> possibleMoves(int stub) {
        try {
            moguci_stubovi = new ArrayList<>();
            int smer = (turn == 0) ? 1 : -1;
            int border = (turn == 0) ? 24 : 1;
            if (smer > 0) {
                // beli igrac
                if (stub == 25) {
                    stub = 0;
                    border = 6;
                }
                for (int i = stub + 1; i <= border; i++) {
                    Stub novi_stub = getStub(i);
                    if (((i - stub == kockice[0]) || (i - stub == kockice[1]) || (i - stub == kockice[0] + kockice[1]))
                            && ((novi_stub.size() <= 1)
                            || (novi_stub.get(novi_stub.size() - 1).getBoja() == trenutnaBoja()))) {
                        dodajCrveni(novi_stub, i - stub);
                    }
                }
            } else {
                // crni
                if (stub == 25) {
                    border = 19;
                }
                for (int i = stub - 1; i >= border; i--) {
                    Stub novi_stub = getStub(i);
                    if (((stub - i == kockice[0]) || (stub - i == kockice[1]) || (stub - i == kockice[0] + kockice[1]))
                            && ((novi_stub.size() <= 1)
                            || (novi_stub.get(novi_stub.size() - 1).getBoja() == trenutnaBoja()))) {
                        dodajCrveni(novi_stub, stub - i);
                    }
                }
            }
            return moguci_stubovi;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public void dodajCrveni(Stub novi_stub, int razlika) {
        if ((novi_stub.size() == 0) || (novi_stub.get(novi_stub.size() - 1).getVidljivost() != Zeton.Vidljivost.POSSIBLE)) {
            moguci_stubovi.add(novi_stub);
            if (drzim != null) {
                Zeton z = new Zeton();
                z.setOdigrano(razlika);
                z.setVidljivost(Zeton.Vidljivost.POSSIBLE);
                novi_stub.add(z);
            }
        }
    }

    public void removePossible() {
        for (Stub s : stubovi) {
            ArrayList<Zeton> odbaceni = new ArrayList<>();
            for (Zeton z : s.getZetoni()) {
                if (z.getVidljivost() == Zeton.Vidljivost.POSSIBLE) {
                    odbaceni.add(z);
                }
            }
            for (Zeton z : odbaceni) {
                s.getZetoni().remove(z);
            }
        }
    }

    public boolean removeDie(int die_result) {
        boolean more_left = false;
        boolean used = false;
        for (int i = 3; i >= 0; i--) {
            if (kockice[i] > 0) {
                if ((kockice[i] == die_result) && !used) {
                    kockice[i] = 0;
                    used = true;
                } else if ((i != 3) && ((kockice[i] + kockice[i + 1]) == die_result) && !used) {
                    kockice[i] = kockice[i + 1] = 0;
                    used = true;
                }
            }
        }
        for (int i = 3; i >= 0; i--) {
            if (kockice[i] > 0)
                more_left = true;
        }
        removePossible();
        return more_left;
    }

    public void nextTurn(Context context) {
        turn = (turn + 1) % 2;
        faza = Faza.BACANJE_KOCKICE;
        savePlayers(context);
    }

    public void saveWinGame(Context context) {
        try {
            int pairID = 0;
            boolean found = false;
            MyOpenHelper helper = new MyOpenHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();
            // String selection = "(" + ScoresEntry.COLUMN_PLAYER1 + "=? AND " + ScoresEntry.COLUMN_PLAYER2 + "=?) OR ("
            //         + ScoresEntry.COLUMN_PLAYER1 + "=? AND " + ScoresEntry.COLUMN_PLAYER2 + "=?)";
            // String[] selectionArgs = {player1Name,player2Name,player2Name, player1Name};
            Cursor c = db.query(ScoresEntry.TABLE_NAME, null, null, null, null, null, null);
            while (c.moveToNext()) {
                String player1 = c.getString(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER1));
                String player2 = c.getString(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER2));
                int id = c.getInt(c.getColumnIndex(ScoresEntry._ID));
                if ((player1.equals(player1Name) && player2.equals(player2Name))
                        || (player1.equals(player2Name) && player2.equals(player1Name))) {

                    pairID = id;

                    //int wins1 = c.getInt(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER1));
                    //int wins2 = c.getInt(c.getColumnIndex(ScoresEntry.COLUMN_PLAYER2));

                    int win = (turn == 0) ? poeni : -poeni;
               /* if (turn == 0) {
                    if (player1.equals(player1Name)) {
                        wins1 += poeni;
                    } else {
                        wins2 += poeni;
                    }
                } else {
                    if (player1.equals(player1Name)) {
                        wins2 += poeni;
                    } else {
                        wins1 += poeni;
                    }
                } */
                    //String selection = ScoresEntry._ID + "=?";
                    // String[] selectArgs = {"" + pairID};
                    if (player1Name.equals(player2)) {
                        win = -win;
                    }
                    ContentValues cv = new ContentValues();
                    cv.put(GamesEntry.COLUMN_PAIR_ID, pairID);
                    cv.put(GamesEntry.COLUMN_POENI, win);
                    db.insert(GamesEntry.TABLE_NAME, null, cv);
                    found = true;
                    break;
                }
                pairID = (pairID < id) ? id : pairID;
            }
            pairID++;
            int wins1 = 0, wins2 = 0;
            if (!found) {
            /*if (turn == 0) {
                wins1 = poeni;
            } else {
                wins2 = poeni;
            }*/
                ContentValues cv = new ContentValues();
                cv.put(ScoresEntry.COLUMN_PLAYER1, player1Name);
                cv.put(ScoresEntry.COLUMN_PLAYER2, player2Name);
                cv.put(ScoresEntry._ID, pairID);
                db.insert(ScoresEntry.TABLE_NAME, null, cv);

                int win = (turn == 0) ? poeni : -poeni;
                cv = new ContentValues();
                cv.put(GamesEntry.COLUMN_PAIR_ID, pairID);
                cv.put(GamesEntry.COLUMN_POENI, win);
                db.insert(GamesEntry.TABLE_NAME, null, cv);
            }
            int gameID = 0;
            c = db.query(TableEntry.TABLE_NAME_WIN, null, null, null, null, null, TableEntry.COLUMN_GAME_ID + " DESC");
            if (c.moveToNext()) {
                gameID = c.getInt(c.getColumnIndex(TableEntry.COLUMN_GAME_ID));
            }
            gameID++;

            c = db.query(TableEntry.TABLE_NAME, null, null, null, null, null, null);
            while (c.moveToNext()) {
                ContentValues cv = new ContentValues();
                cv.put(TableEntry.COLUMN_COUNT, c.getInt(c.getColumnIndex(TableEntry.COLUMN_COUNT)));
                cv.put(TableEntry.COLUMN_COLOR, c.getInt(c.getColumnIndex(TableEntry.COLUMN_COLOR)));
                cv.put(TableEntry.COLUMN_FIELD, c.getInt(c.getColumnIndex(TableEntry.COLUMN_FIELD)));
                cv.put(TableEntry.COLUMN_PAIR_ID, pairID);
                cv.put(TableEntry.COLUMN_GAME_ID, gameID);
                db.insert(TableEntry.TABLE_NAME_WIN, null, cv);
            }

            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveGameStub(int stub, Context context) {
        try {
            MyOpenHelper helper = new MyOpenHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();

            String selection = TableEntry.COLUMN_FIELD + "=?";
            String[] selectionArgs = {"" + stub};
            db.delete(TableEntry.TABLE_NAME, selection, selectionArgs);

            //Cursor c = db.query(TableEntry.TABLE_NAME, null,null,null, null, null, null);
            ContentValues cv = new ContentValues();
            if (stub < 25) {
                cv.put(TableEntry.COLUMN_COUNT, getStub(stub).size());
                if (getStub(stub).size() == 0)
                    cv.put(TableEntry.COLUMN_COLOR, 0);
                else
                    cv.put(TableEntry.COLUMN_COLOR, (getStub(stub).get(0).getBoja() == Zeton.Boja.BELA) ? 0 : 1);
                cv.put(TableEntry.COLUMN_FIELD, stub);
                db.insert(TableEntry.TABLE_NAME, null, cv);
            } else {
                int bele = 0;
                for (Zeton z : bar.getZetoni()) {
                    if (z.getBoja() == Zeton.Boja.BELA) {
                        bele++;
                    }
                }
                cv = new ContentValues();
                cv.put(TableEntry.COLUMN_COUNT, bele);
                cv.put(TableEntry.COLUMN_COLOR, 0);
                cv.put(TableEntry.COLUMN_FIELD, 25);
                db.insert(TableEntry.TABLE_NAME, null, cv);

                cv = new ContentValues();
                cv.put(TableEntry.COLUMN_COUNT, bar.size() - bele);
                cv.put(TableEntry.COLUMN_COLOR, 1);
                cv.put(TableEntry.COLUMN_FIELD, 25);
                db.insert(TableEntry.TABLE_NAME, null, cv);
            }
            //c = db.query(TableEntry.TABLE_NAME, null,null,null, null, null, null);

            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveGameDice(Context context) {
        try {
            MyOpenHelper helper = new MyOpenHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();
            db.delete(DiceEntry.TABLE_NAME, null, null);

            for (int kocka : kockice) {
                ContentValues cv = new ContentValues();
                cv.put(DiceEntry.COLUMN_NUMBER, kocka);
                db.insert(DiceEntry.TABLE_NAME, null, cv);
            }

            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void savePlayers(Context context) {
        try {
            MyOpenHelper helper = new MyOpenHelper(context);
            SQLiteDatabase db = helper.getWritableDatabase();
            db.delete(PlayerEntry.TABLE_NAME, null, null);
            ContentValues cv = new ContentValues();
            cv.put(PlayerEntry.COLUMN_PLAYER, player1Name);
            cv.put(PlayerEntry.COLUMN_COLOR, 0);
            cv.put(PlayerEntry.COLUMN_MY_TURN, (turn == 0) ? 1 : 0);
            db.insert(PlayerEntry.TABLE_NAME, null, cv);

            cv = new ContentValues();
            cv.put(PlayerEntry.COLUMN_PLAYER, player2Name);
            cv.put(PlayerEntry.COLUMN_COLOR, 1);
            cv.put(PlayerEntry.COLUMN_MY_TURN, (turn == 1) ? 1 : 0);
            db.insert(PlayerEntry.TABLE_NAME, null, cv);
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void hit(Stub stub) {
        Zeton z = stub.getZetoni().remove(0);
        bar.add(z);
    }

    public boolean onTheBar(Zeton.Boja boja) {
        for (Zeton z : bar.getZetoni()) {
            if (z.getBoja() == boja)
                return true;
        }
        return false;
    }



    public boolean josKockica() {
        for (int i = 0; i < 4; i++) {
            if (kockice[i] > 0)
                return true;
        }
        return false;
    }

    public Zeton.Boja trenutnaBoja() {
        return (turn == 0) ? Zeton.Boja.BELA : Zeton.Boja.CRNA;
    }

    public boolean canBearOff() {
        if (!josKockica())
            return false;
        if (trenutnaBoja() == Zeton.Boja.CRNA) {
            for (int i = 7; i <= 24; i++) {
                Stub s = getStub(i);
                if ((s.size() > 0) && (s.get(0).getBoja() == trenutnaBoja()))
                    return false;
            }
        } else {
            for (int i = 1; i <= 18; i++) {
                Stub s = getStub(i);
                if ((s.size() > 0) && (s.get(0).getBoja() == trenutnaBoja())) {
                    return false;
                }
            }
        }
        for (Zeton z : bar.getZetoni()) {
            if (z.getBoja() == trenutnaBoja())
                return false;
        }
        return true;
    }

    public void loadGame(Context context) {
        stubovi.clear();
        try {
            MyOpenHelper helper = new MyOpenHelper(context);
            String projection[] = new String[]{TableEntry._ID,
                    TableEntry.COLUMN_FIELD, TableEntry.COLUMN_COLOR, TableEntry.COLUMN_COUNT};
            SQLiteDatabase db = helper.getWritableDatabase();
            Cursor c = null;
            c = db.query(TableEntry.TABLE_NAME, projection, null, null, null, null, TableEntry.COLUMN_FIELD + " ASC");
            int id = 0;
            while (c.moveToNext()) {
                if (id < 24) {
                    int brojZetona = c.getInt(c.getColumnIndex(TableEntry.COLUMN_COUNT));
                    Stub s = new Stub();
                    Zeton.Boja boja = (c.getInt(c.getColumnIndex(TableEntry.COLUMN_COLOR)) == 0) ? Zeton.Boja.BELA : Zeton.Boja.CRNA;
                    for (int i = 0; i < brojZetona; i++) {
                        s.add(new Zeton(boja));
                    }
                    s.setId(++id);
                    stubovi.add(s);
                } else {
                    int brojZetona = c.getInt(c.getColumnIndex(TableEntry.COLUMN_COUNT));
                    Zeton.Boja boja = (c.getInt(c.getColumnIndex(TableEntry.COLUMN_COLOR)) == 0) ? Zeton.Boja.BELA : Zeton.Boja.CRNA;
                    for (int i = 0; i < brojZetona; i++) {
                        bar.add(new Zeton(boja));
                    }
                }
            }
            String projection1[] = new String[]{DiceEntry._ID, DiceEntry.COLUMN_NUMBER};
            c = db.query(DiceEntry.TABLE_NAME, projection1, null, null, null, null, DiceEntry.COLUMN_NUMBER + " DESC");
            int i = 0;
            while (c.moveToNext()) {
                kockice[i++] = c.getInt(c.getColumnIndex(DiceEntry.COLUMN_NUMBER));
            }
            if (kockice[0] > 0)
                faza = Faza.POMERANJE;
            String projection2[] = new String[]{PlayerEntry._ID, PlayerEntry.COLUMN_PLAYER, PlayerEntry.COLUMN_COLOR, PlayerEntry.COLUMN_MY_TURN};
            c = db.query(PlayerEntry.TABLE_NAME, projection2, null, null, null, null, PlayerEntry.COLUMN_COLOR + " ASC");
            while (c.moveToNext()) {
                String name = c.getString(c.getColumnIndex(PlayerEntry.COLUMN_PLAYER));
                int myTurn = c.getInt(c.getColumnIndex(PlayerEntry.COLUMN_MY_TURN));
                int bojaIndex = c.getInt(c.getColumnIndex(PlayerEntry.COLUMN_COLOR));
                if (name.equals("WALL·E")) {
                    player1Type = PlayerType.COMPUTER;
                    player1Name = name;
                } else if (name.equals("EVE")) {
                    player2Type = PlayerType.COMPUTER;
                    player2Name = name;
                } else {
                    if (bojaIndex == 0) {
                        player1Type = PlayerType.PLAYER;
                        player1Name = name;
                    } else {
                        player2Type = PlayerType.PLAYER;
                        player2Name = name;
                    }
                }
                turn = (myTurn == 1) ? bojaIndex : turn;
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadWin(Context context, Victory pair) {
        stubovi.clear();
        try {
            MyOpenHelper helper = new MyOpenHelper(context);
            String projection[] = new String[]{TableEntry._ID,
                    TableEntry.COLUMN_FIELD, TableEntry.COLUMN_COLOR, TableEntry.COLUMN_COUNT};
            SQLiteDatabase db = helper.getWritableDatabase();
            String selection = TableEntry.COLUMN_GAME_ID + "=?";
            String[] selectionArgs = {"" + pair.getGameId()};
            Cursor c = db.query(TableEntry.TABLE_NAME_WIN, projection, selection, selectionArgs, null, null, TableEntry.COLUMN_FIELD + " ASC");
            int id = 0;
            while (c.moveToNext()) {
                if (id < 24) {
                    int brojZetona = c.getInt(c.getColumnIndex(TableEntry.COLUMN_COUNT));
                    Stub s = new Stub();
                    Zeton.Boja boja = (c.getInt(c.getColumnIndex(TableEntry.COLUMN_COLOR)) == 0) ? Zeton.Boja.BELA : Zeton.Boja.CRNA;
                    for (int i = 0; i < brojZetona; i++) {
                        s.add(new Zeton(boja));
                    }
                    s.setId(++id);
                    stubovi.add(s);
                } else {
                    int brojZetona = c.getInt(c.getColumnIndex(TableEntry.COLUMN_COUNT));
                    Zeton.Boja boja = (c.getInt(c.getColumnIndex(TableEntry.COLUMN_COLOR)) == 0) ? Zeton.Boja.BELA : Zeton.Boja.CRNA;
                    for (int i = 0; i < brojZetona; i++) {
                        bar.add(new Zeton(boja));
                    }
                }
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isTheEnd() {
        for (Stub s : stubovi) {
            if ((s.size() > 0) && (s.get(0).getBoja() == trenutnaBoja()))
                return false;
        }
        for (Zeton z : bar.getZetoni()) {
            if (z.getBoja() == trenutnaBoja())
                return false;
        }
        return true;
    }

    public int poeni() {
        Zeton.Boja protivnicka = (trenutnaBoja() == Zeton.Boja.BELA) ? Zeton.Boja.CRNA : Zeton.Boja.BELA;
        int broj_zetona = 0;
        for (Zeton z : bar.getZetoni()) {
            if (z.getBoja() == protivnicka)
                return poeni = 3;
        }
        for (int i = 1; i <= 24; i++) {
            Stub s = getStub(i);
            if (s.size() > 0) {
                if ((protivnicka == Zeton.Boja.BELA) && (i <= 6))
                    return poeni = 3;
                else if ((protivnicka == Zeton.Boja.CRNA) && (i >= 19))
                    return poeni = 3;
                broj_zetona += s.size();
            }
        }
        if (broj_zetona == 15)
            return poeni = 2;
        return poeni = 1;
    }


    public PlayerType getPlayer1Type() {
        return player1Type;
    }

    public void setPlayer1Type(PlayerType player1Type) {
        this.player1Type = player1Type;
    }

    public PlayerType getPlayer2Type() {
        return player2Type;
    }

    public void setPlayer2Type(PlayerType player2Type) {
        this.player2Type = player2Type;
    }

    public String getPlayer1Name() {
        return player1Name;
    }

    public void setPlayer1Name(String player1Name) {
        this.player1Name = player1Name;
    }

    public String getPlayer2Name() {
        return player2Name;
    }

    public void setPlayer2Name(String player2Name) {
        this.player2Name = player2Name;
    }

    public int[] getKockice() {
        return kockice;
    }

    public void setKockice(int[] kockice) {
        this.kockice = kockice;
    }

    public ArrayList<Stub> getStubovi() {
        return stubovi;
    }

    public void setStubovi(ArrayList<Stub> stubovi) {
        this.stubovi = stubovi;
    }

    public int getTurn() {
        return turn;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }

    public double getDrzim_x() {
        return drzim_x;
    }

    public void setDrzim_x(double drzim_x) {
        this.drzim_x = drzim_x;
    }

    public double getDrzim_y() {
        return drzim_y;
    }

    public void setDrzim_y(double drzim_y) {
        this.drzim_y = drzim_y;
    }

    public Zeton getDrzim() {
        return drzim;
    }

    public void setDrzim(Zeton drzim) {
        this.drzim = drzim;
    }

    public Faza getFaza() {
        return faza;
    }

    public void setFaza(Faza faza) {
        this.faza = faza;
    }

    public int getUzet_sa_stuba() {
        return uzet_sa_stuba;
    }

    public void setUzet_sa_stuba(int uzet_sa_stuba) {
        this.uzet_sa_stuba = uzet_sa_stuba;
    }

    public ArrayList<Stub> getMoguci_stubovi() {
        return moguci_stubovi;
    }

    public void setMoguci_stubovi(ArrayList<Stub> moguci_stubovi) {
        this.moguci_stubovi = moguci_stubovi;
    }

    public Stub getBar() {
        return bar;
    }

    public void setBar(Stub bar) {
        this.bar = bar;
    }

    public int getPoeni() {
        return poeni;
    }

    public void setPoeni(int poeni) {
        this.poeni = poeni;
    }

    public AI getAi1() {
        return ai1;
    }

    public void setAi1(AI ai1) {
        this.ai1 = ai1;
    }

    public AI getAi2() {
        return ai2;
    }

    public void setAi2(AI ai2) {
        this.ai2 = ai2;
    }

    public int getUpperThreshold() {
        return upperThreshold;
    }

    public void setUpperThreshold(int upperThreshold) {
        this.upperThreshold = upperThreshold;
    }

    public double getScale() {
        return scale;
    }

    public void setScale(double scale) {
        this.scale = scale;
    }

}
