package com.example.mina.backgammon.database;

import android.provider.BaseColumns;

/**
 * Created by Mina on 15-Jan-18.
 */
// Par igraca. Za rezultat pogledaj tabelu GameEntry
public class ScoresEntry implements BaseColumns {

        public static final String TABLE_NAME = "Poeni";
        public static final String COLUMN_PLAYER1 = "igrac1";
        public static final String COLUMN_PLAYER2 = "igrac2";
}
