package com.example.mina.backgammon.beans;

import java.io.Serializable;

/**
 * Created by Mina on 20-Jan-18.
 */

public class Zeton implements Serializable {
    public enum Boja {
        CRNA,
        BELA
    }
    public enum Vidljivost {
        PERMANENT,
        POSSIBLE
    }
    private Boja boja = Boja.BELA;
    private Vidljivost vidljivost= Vidljivost.PERMANENT;
    private int odigrano = 0;

    public Zeton(Boja boja) {
        this.boja = boja;
    }

    public Zeton() {
    }

    public Boja getBoja() {
        return boja;
    }

    public void setBoja(Boja boja) {
        this.boja = boja;
    }

    public Vidljivost getVidljivost() {
        return vidljivost;
    }

    public void setVidljivost(Vidljivost visibility) {
        this.vidljivost = visibility;
    }

    public int getOdigrano() {
        return odigrano;
    }

    public void setOdigrano(int odigrano) {
        this.odigrano = odigrano;
    }
}
